import urllib.request
import json
import time

BASE_URL = "http://localhost:8080"

def post_json(endpoint, data):
    req = urllib.request.Request(
        f"{BASE_URL}{endpoint}",
        data=json.dumps(data).encode('utf-8'),
        headers={'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode('utf-8'))

def get_json(endpoint):
    req = urllib.request.Request(f"{BASE_URL}{endpoint}")
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read().decode('utf-8'))

def run_e2e_test():
    print("[1] Starting automated test suite...")

    # Step 1: Start a candidate session
    start_resp = post_json("/api/session/start", {"candidate_name": "Test Candidate Alpha"})
    session_id = start_resp["session_id"]
    print(f" -> Session created: {session_id}")

    # Step 2: Fetch first question
    q_resp = get_json(f"/api/session/{session_id}/question")
    assert not q_resp["completed"], "Expected active question"
    print(f" -> Question 1 fetched: '{q_resp['question'][:50]}...'")

    # Step 3: Stream telemetry events
    print(" -> Simulating telemetry incidents (blur, visibilitychange, shortcut)...")
    post_json("/api/session/telemetry", {
        "session_id": session_id,
        "event_type": "visibility_hidden",
        "details": "User switched tabs away from test."
    })
    post_json("/api/session/telemetry", {
        "session_id": session_id,
        "event_type": "blur",
        "details": "Focus lost to external window."
    })
    post_json("/api/session/telemetry", {
        "session_id": session_id,
        "event_type": "dev_tools_key",
        "details": "F12 key pressed."
    })

    # Step 4: Submit answers (including an unnaturally rapid answer to trigger velocity penalty)
    print(" -> Submitting question responses...")
    # Answer 1 (normal pace)
    time.sleep(1.0)
    post_json("/api/session/submit", {"session_id": session_id, "selected_option": 0})

    # Answer 2, 3, 4
    for _ in range(3):
        get_json(f"/api/session/{session_id}/question")
        post_json("/api/session/submit", {"session_id": session_id, "selected_option": 1})

    # Step 5: Conclude exam
    finish_resp = post_json("/api/session/finish", {"session_id": session_id})
    risk_score = finish_resp["risk_score"]
    print(f" -> Exam completed. Calculated Risk Score: {risk_score}%")
    assert risk_score > 0, "Risk score should reflect recorded telemetry anomalies"

    # Step 6: Proctor review workflow
    proctor_list = get_json("/api/proctor/sessions")
    found = any(s["session_id"] == session_id for s in proctor_list["sessions"])
    assert found, "Session must appear in proctor dashboard"
    print(" -> Verified session visible in proctor dashboard.")

    audit_detail = get_json(f"/api/proctor/session/{session_id}")
    assert len(audit_detail["events"]) >= 3, "All telemetry events must be persisted in audit trail"
    print(f" -> Audit log verified: {len(audit_detail['events'])} incidents chronologically recorded.")

    # Step 7: Proctor assigns decision
    decision_resp = post_json(f"/api/proctor/session/{session_id}/review", {
        "decision": "flagged",
        "notes": "Candidate experienced multiple focus shifts and DevTools shortcut attempts."
    })
    assert decision_resp["success"], "Review decision must be committed"
    print(f" -> Proctor decision updated to: '{decision_resp['proctor_status']}'.")

    print("\n✅ ALL INTEGRATION & AUDIT TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    run_e2e_test()
