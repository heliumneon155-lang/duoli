import http.server
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from api.index import handler, init_db, PORT, PUBLIC_DIR

class LocalDevHandler(handler):
    def do_GET(self):
        # Route API paths to the serverless handler
        if self.path.startswith("/api/"):
            return super().do_GET()

        # Handle static files from public directory
        req_path = self.path.split("?")[0]
        if req_path == "/" or req_path == "":
            req_path = "/index.html"

        file_path = os.path.join(PUBLIC_DIR, req_path.lstrip("/"))
        if os.path.exists(file_path) and os.path.isfile(file_path):
            self.send_response(200)
            if file_path.endswith(".html"):
                self.send_header("Content-Type", "text/html; charset=utf-8")
            elif file_path.endswith(".css"):
                self.send_header("Content-Type", "text/css; charset=utf-8")
            elif file_path.endswith(".js"):
                self.send_header("Content-Type", "application/javascript; charset=utf-8")
            self.end_headers()
            with open(file_path, "rb") as f:
                self.wfile.write(f.read())
        else:
            self.send_error(404, f"File not found: {req_path}")

def run():
    init_db()
    server_address = ('', PORT)
    httpd = http.server.ThreadingHTTPServer(server_address, LocalDevHandler)
    print(f"=== Secure Exam & Proctoring Platform running locally on http://localhost:{PORT} ===")
    print("Press Ctrl+C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
        httpd.server_close()

if __name__ == "__main__":
    run()
