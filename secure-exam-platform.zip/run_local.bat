@echo off
echo Starting Secure Assessment & Proctoring Platform...
cd /d "%~dp0"
python server.py
pause
