import http.server
import json
import sqlite3
import time
import os
import urllib.parse
from datetime import datetime

PORT = 8080
PUBLIC_DIR = os.path.join(os.path.dirname(__file__), "..", "public")

# In Vercel serverless environments, file writes are restricted to /tmp
if os.environ.get("VERCEL"):
    DB_FILE = "/tmp/exam_platform.db"
else:
    DB_FILE = os.path.join(os.path.dirname(__file__), "..", "exam_platform.db")

QUESTIONS = [
    {
        "id": 1,
        "question": "Which of the following describes the difference between client-side and server-side validation?",
        "options": [
            "Client-side validation provides instant UI feedback, while server-side validation is authoritative for security.",
            "Client-side validation is completely tamper-proof if JavaScript is obfuscated.",
            "Server-side validation is only needed when client-side validation fails.",
            "Both provide identical security guarantees in modern web browsers."
        ],
        "correct": 0,
        "min_expected_sec": 4.0
    },
    {
        "id": 2,
        "question": "Why is document.visibilityState alone insufficient to guarantee examination integrity?",
        "options": [
            "It only fires when the browser crashes.",
            "Secondary monitors, virtual machines, and physical external devices are not detected by browser DOM events.",
            "The event is deprecated in HTML5.",
            "It cannot be read asynchronously by JavaScript."
        ],
        "correct": 1,
        "min_expected_sec": 4.0
    },
    {
        "id": 3,
        "question": "In a robust assessment platform, how should answer submissions be validated?",
        "options": [
            "Calculate the final score in localStorage and send only the total to the server.",
            "Rely entirely on the client timer to reject late submissions.",
            "Track question issuance timestamps server-side and verify that submission time falls within allowed bounds.",
            "Disable network encryption to speed up real-time proctoring streams."
        ],
        "correct": 2,
        "min_expected_sec": 4.0
    },
    {
        "id": 4,
        "question": "What is the primary role of an audit trail in human-in-the-loop proctoring?",
        "options": [
            "To automatically fail any candidate experiencing network jitter.",
            "To provide time-stamped contextual evidence so a qualified reviewer can make an informed decision.",
            "To replace human judgment with irreversible automated disqualification.",
            "To record candidate passwords for authentication verification."
        ],
        "correct": 1,
        "min_expected_sec": 3.5
    }
]

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            candidate_name TEXT,
            started_at REAL,
            ended_at REAL,
            status TEXT DEFAULT 'in_progress',
            current_question_idx INTEGER DEFAULT 0,
            question_started_at REAL,
            score INTEGER DEFAULT 0,
            risk_score INTEGER DEFAULT 0,
            proctor_status TEXT DEFAULT 'pending',
            proctor_notes TEXT DEFAULT '',
            last_heartbeat REAL
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS telemetry_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            event_type TEXT,
            timestamp REAL,
            details TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            question_id INTEGER,
            selected_option INTEGER,
            response_time_sec REAL,
            is_correct INTEGER,
            submitted_at REAL
        )
    ''')
    conn.commit()
    conn.close()

# Auto-initialize database on import/startup
init_db()

def calculate_risk(session_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    c.execute("SELECT event_type, COUNT(*) FROM telemetry_events WHERE session_id = ? GROUP BY event_type", (session_id,))
    event_counts = dict(c.fetchall())
    
    c.execute("SELECT question_id, response_time_sec FROM answers WHERE session_id = ?", (session_id,))
    answers = c.fetchall()
    
    score = 0
    score += event_counts.get("visibility_hidden", 0) * 15
    score += event_counts.get("blur", 0) * 10
    score += event_counts.get("fullscreen_exit", 0) * 20
    score += event_counts.get("paste_attempt", 0) * 25
    score += event_counts.get("dev_tools_key", 0) * 20

    for q_id, resp_time in answers:
        q_meta = next((q for q in QUESTIONS if q["id"] == q_id), None)
        if q_meta and resp_time < q_meta["min_expected_sec"]:
            score += 15

    c.execute("SELECT started_at, ended_at FROM sessions WHERE session_id = ?", (session_id,))
    s_row = c.fetchone()
    if s_row and s_row[0] and s_row[1]:
        duration = s_row[1] - s_row[0]
        c.execute("SELECT COUNT(*) FROM telemetry_events WHERE session_id = ? AND event_type = 'heartbeat'", (session_id,))
        hb_count = c.fetchone()[0]
        expected_hbs = max(1, int(duration / 5.0))
        if hb_count < expected_hbs * 0.5:
            score += 20

    risk_score = min(100, score)
    c.execute("UPDATE sessions SET risk_score = ? WHERE session_id = ?", (risk_score, session_id))
    conn.commit()
    conn.close()
    return risk_score

class handler(http.server.BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(json.dumps(payload).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        init_db()
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else b'{}'
        try:
            data = json.loads(body.decode('utf-8'))
        except Exception:
            data = {}

        if path == "/api/session/start":
            self.handle_session_start(data)
        elif path == "/api/session/telemetry":
            self.handle_telemetry(data)
        elif path == "/api/session/heartbeat":
            self.handle_heartbeat(data)
        elif path == "/api/session/submit":
            self.handle_submit(data)
        elif path == "/api/session/finish":
            self.handle_finish(data)
        elif path.startswith("/api/proctor/session/") and path.endswith("/review"):
            session_id = path.split("/")[4]
            self.handle_proctor_review(session_id, data)
        else:
            self.send_error(404, "Endpoint not found")

    def do_GET(self):
        init_db()
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/session/") and path.endswith("/question"):
            session_id = path.split("/")[3]
            self.handle_get_question(session_id)
        elif path == "/api/proctor/sessions":
            self.handle_proctor_list()
        elif path.startswith("/api/proctor/session/"):
            session_id = path.split("/")[4]
            self.handle_proctor_detail(session_id)
        else:
            self.send_json(404, {"error": "API route not found"})

    def handle_session_start(self, data):
        candidate_name = data.get("candidate_name", "Anonymous Candidate").strip()
        session_id = f"exam_{int(time.time()*1000)}"
        now = time.time()
        
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''
            INSERT INTO sessions (session_id, candidate_name, started_at, current_question_idx, question_started_at, last_heartbeat)
            VALUES (?, ?, ?, 0, ?, ?)
        ''', (session_id, candidate_name, now, now, now))
        conn.commit()
        conn.close()

        self.send_json(200, {"session_id": session_id, "total_questions": len(QUESTIONS)})

    def handle_get_question(self, session_id):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT current_question_idx, status FROM sessions WHERE session_id = ?", (session_id,))
        row = c.fetchone()
        
        if not row:
            conn.close()
            return self.send_json(404, {"error": "Session not found"})
        
        q_idx, status = row
        if status != "in_progress" or q_idx >= len(QUESTIONS):
            conn.close()
            return self.send_json(200, {"completed": True})

        q = QUESTIONS[q_idx]
        now = time.time()
        c.execute("UPDATE sessions SET question_started_at = ? WHERE session_id = ?", (now, session_id))
        conn.commit()
        conn.close()

        self.send_json(200, {
            "completed": False,
            "question_index": q_idx + 1,
            "total_questions": len(QUESTIONS),
            "id": q["id"],
            "question": q["question"],
            "options": q["options"]
        })

    def handle_submit(self, data):
        session_id = data.get("session_id")
        selected_option = data.get("selected_option")
        now = time.time()

        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT current_question_idx, question_started_at, score, status FROM sessions WHERE session_id = ?", (session_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            return self.send_json(404, {"error": "Session not found"})

        q_idx, q_started, score, status = row
        if status != "in_progress" or q_idx >= len(QUESTIONS):
            conn.close()
            return self.send_json(400, {"error": "Exam not active"})

        q = QUESTIONS[q_idx]
        response_time = max(0.0, now - (q_started or now))
        is_correct = 1 if selected_option == q["correct"] else 0
        new_score = score + is_correct

        c.execute('''
            INSERT INTO answers (session_id, question_id, selected_option, response_time_sec, is_correct, submitted_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (session_id, q["id"], selected_option, round(response_time, 2), is_correct, now))

        next_idx = q_idx + 1
        c.execute('''
            UPDATE sessions 
            SET current_question_idx = ?, score = ?, question_started_at = ?
            WHERE session_id = ?
        ''', (next_idx, new_score, now, session_id))
        conn.commit()
        conn.close()

        self.send_json(200, {
            "success": True,
            "next_index": next_idx + 1,
            "has_next": next_idx < len(QUESTIONS)
        })

    def handle_telemetry(self, data):
        session_id = data.get("session_id")
        event_type = data.get("event_type")
        details = data.get("details", "")
        now = time.time()

        if not session_id or not event_type:
            return self.send_json(400, {"error": "Invalid telemetry payload"})

        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''
            INSERT INTO telemetry_events (session_id, event_type, timestamp, details)
            VALUES (?, ?, ?, ?)
        ''', (session_id, event_type, now, details))
        conn.commit()
        conn.close()

        self.send_json(200, {"logged": True})

    def handle_heartbeat(self, data):
        session_id = data.get("session_id")
        now = time.time()
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("UPDATE sessions SET last_heartbeat = ? WHERE session_id = ?", (now, session_id))
        c.execute("INSERT INTO telemetry_events (session_id, event_type, timestamp, details) VALUES (?, 'heartbeat', ?, 'pulse')", (session_id, now))
        conn.commit()
        conn.close()
        self.send_json(200, {"status": "alive"})

    def handle_finish(self, data):
        session_id = data.get("session_id")
        now = time.time()
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("UPDATE sessions SET ended_at = ?, status = 'completed' WHERE session_id = ?", (now, session_id))
        conn.commit()
        conn.close()

        risk = calculate_risk(session_id)
        self.send_json(200, {"status": "finished", "risk_score": risk})

    def handle_proctor_list(self):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''
            SELECT session_id, candidate_name, started_at, ended_at, status, score, risk_score, proctor_status, last_heartbeat
            FROM sessions ORDER BY started_at DESC
        ''')
        rows = c.fetchall()
        now = time.time()
        sessions = []
        for r in rows:
            is_active = (r[4] == 'in_progress') and (now - (r[8] or 0) < 15.0)
            sessions.append({
                "session_id": r[0],
                "candidate_name": r[1],
                "started_at": datetime.fromtimestamp(r[2]).strftime('%Y-%m-%d %H:%M:%S') if r[2] else "-",
                "ended_at": datetime.fromtimestamp(r[3]).strftime('%Y-%m-%d %H:%M:%S') if r[3] else "-",
                "status": "active" if is_active else r[4],
                "score": f"{r[5]}/{len(QUESTIONS)}",
                "risk_score": r[6],
                "proctor_status": r[7]
            })
        conn.close()
        self.send_json(200, {"sessions": sessions})

    def handle_proctor_detail(self, session_id):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT session_id, candidate_name, started_at, ended_at, status, score, risk_score, proctor_status, proctor_notes FROM sessions WHERE session_id = ?", (session_id,))
        s = c.fetchone()
        if not s:
            conn.close()
            return self.send_json(404, {"error": "Session not found"})

        c.execute("SELECT event_type, timestamp, details FROM telemetry_events WHERE session_id = ? AND event_type != 'heartbeat' ORDER BY timestamp ASC", (session_id,))
        events = [{"type": e[0], "time": datetime.fromtimestamp(e[1]).strftime('%H:%M:%S'), "details": e[2]} for e in c.fetchall()]

        c.execute("SELECT question_id, selected_option, response_time_sec, is_correct FROM answers WHERE session_id = ? ORDER BY id ASC", (session_id,))
        answers = [{"q_id": a[0], "selected": a[1], "time_sec": a[2], "correct": bool(a[3])} for a in c.fetchall()]
        conn.close()

        self.send_json(200, {
            "session": {
                "id": s[0],
                "name": s[1],
                "started": datetime.fromtimestamp(s[2]).strftime('%Y-%m-%d %H:%M:%S') if s[2] else "-",
                "ended": datetime.fromtimestamp(s[3]).strftime('%Y-%m-%d %H:%M:%S') if s[3] else "-",
                "status": s[4],
                "score": f"{s[5]}/{len(QUESTIONS)}",
                "risk_score": s[6],
                "proctor_status": s[7],
                "proctor_notes": s[8]
            },
            "events": events,
            "answers": answers
        })

    def handle_proctor_review(self, session_id, data):
        decision = data.get("decision", "pending")
        notes = data.get("notes", "")

        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("UPDATE sessions SET proctor_status = ?, proctor_notes = ? WHERE session_id = ?", (decision, notes, session_id))
        conn.commit()
        conn.close()

        self.send_json(200, {"success": True, "proctor_status": decision})
