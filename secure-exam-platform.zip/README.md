# Secure Assessment & Proctoring Platform

A full-stack, dual-tier examination architecture featuring **automated client telemetry analysis** and an **asynchronous human-in-the-loop proctoring dashboard**, configured for **instant deployment to Vercel** or local execution.

---

## Project Structure

```
secure-exam-platform/
├── vercel.json               # Vercel deployment configuration & route rewrites
├── requirements.txt          # Python runtime marker for Vercel
├── api/
│   └── index.py              # Vercel Serverless Function (Python BaseHTTPRequestHandler)
├── server.py                 # Local development server with static file serving & live reloading
├── test_suite.py             # Automated end-to-end integration and telemetry test suite
├── kiosk_electron_main.js    # Native desktop kiosk lockdown blueprint
└── public/
    ├── index.html            # Candidate entry & camera pre-checks
    ├── exam.html             # Proctored test environment with live telemetry streams
    ├── proctor.html          # Proctor authority review dashboard & audit timeline
    └── styles.css            # Dark-theme UI design system
```

---

## Deploying to Vercel

The platform is structured to deploy directly to Vercel with zero extra build steps:

### Option 1: Deploy via GitHub (Recommended)
1. Upload or push this folder (`secure-exam-platform`) to a new repository on your GitHub account.
2. Go to your [Vercel Dashboard](https://vercel.com/dashboard) and click **"Add New Project"**.
3. Select your repository and click **Deploy**.
   - **Framework Preset:** *Other* (detected automatically via `vercel.json`).
   - **Root Directory:** `./`
4. Once deployed, Vercel gives you a live production URL (e.g., `https://your-exam-project.vercel.app`).

### Option 2: Deploy via Vercel CLI
If you have the Vercel CLI installed on any machine:
```bash
npm install -g vercel
cd secure-exam-platform
vercel
```

---

## Serverless Database Architecture Note

- In local development, the server writes persistent audit logs directly to `exam_platform.db`.
- When deployed on Vercel (`VERCEL=1`), `api/index.py` automatically routes SQLite operations to the writable `/tmp/exam_platform.db` directory.
- *For production multi-instance persistence:* To persist candidate logs across multiple distributed serverless instances over days or weeks, replace the SQLite connection in `api/index.py` with an external cloud database (such as **Vercel Postgres**, **Neon**, **Supabase**, or **Turso**).

---

## Local Development & Testing

1. **Start the Local Server:**
   ```bash
   python server.py
   ```
   *Runs locally on `http://localhost:8080`*

2. **Access the Portals:**
   - **Candidate Portal:** [http://localhost:8080](http://localhost:8080)
   - **Proctor Authority Dashboard:** [http://localhost:8080/proctor.html](http://localhost:8080/proctor.html)

3. **Run the Automated Test Suite:**
   ```bash
   python test_suite.py
   ```
