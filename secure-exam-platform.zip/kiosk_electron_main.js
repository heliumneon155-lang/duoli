/**
 * Native Kiosk Wrapper Configuration (Electron)
 * 
 * Used by international assessment clients (e.g. Duolingo English Test, Safe Exam Browser)
 * to enforce OS-level isolation that standard web browsers cannot achieve.
 */

const { app, BrowserWindow, globalShortcut } = require('electron');

let mainWindow;

function createKioskWindow() {
  mainWindow = new BrowserWindow({
    kiosk: true,                    // Locks application to true kiosk fullscreen
    alwaysOnTop: true,              // Prevents other desktop windows from overlaying
    autoHideMenuBar: true,
    fullscreen: true,
    frame: false,
    webPreferences: {
      devTools: false,              // Disables Chrome Developer Tools
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  // Load the local proctored examination URL
  mainWindow.loadURL('http://localhost:8080');

  // Prevent navigation to external domains
  mainWindow.webContents.on('will-navigate', (event, navigationUrl) => {
    const parsedUrl = new URL(navigationUrl);
    if (parsedUrl.origin !== 'http://localhost:8080') {
      event.preventDefault();
      console.warn(`Blocked unauthorized navigation to: ${navigationUrl}`);
    }
  });

  // Intercept and disable dangerous OS shortcut combinations
  globalShortcut.register('CommandOrControl+Shift+I', () => false);
  globalShortcut.register('CommandOrControl+R', () => false);
  globalShortcut.register('F11', () => false);
  globalShortcut.register('F12', () => false);
  globalShortcut.register('Alt+Tab', () => false);

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createKioskWindow);

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});
